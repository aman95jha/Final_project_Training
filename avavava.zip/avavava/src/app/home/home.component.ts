
import { Component, OnInit, EventEmitter} from "@angular/core";
import { UserDatabaseModel } from 'src/entity/UserDatabase';
import { UserDatabaseService } from 'src/service/user-database.service';
import { FormGroup , FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { element } from 'protractor';
import { from } from 'rxjs';
import { Action } from 'rxjs/internal/scheduler/Action';
@Component({ 
selector: 'app-home',
templateUrl: './home.component.html',
styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit{

  userDetails: UserDatabaseModel[];
  myForm: FormGroup;
  constructor( private service: UserDatabaseService, private router: Router) { }
  
    ngOnInit(): void{
      this.service.getAllUserDatabase().subscribe(data =>{
        this.userDetails = data.body;
        console.log(data.body)
      });
      {
        this.myForm = new FormGroup({
          name: new FormControl(''),
          action: new FormControl('')
        });
      }
    }
    onSubmit(form: FormGroup){
      var k=0;
      for(var i=0; i<this.userDetails.length;i++){
        if(this.userDetails[i].username==form.value.name &&
            this.userDetails[i].password==form.value.action &&
              this.userDetails[i].confirmation=="confirmed")
              {
                k=1;
                if(this.userDetails[i].user_type=="admin")
                {
                  this.router.navigate(['/admin'])
                }
                if(this.userDetails[i].user_type=="user")
                {
                  this.router.navigate(['/user'])
                }
              }
        
      }
      if(k==0)
        {
          alert("Incorrect Username Or Password");
        }
    }

}
