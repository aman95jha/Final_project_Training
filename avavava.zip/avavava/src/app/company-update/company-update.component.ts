import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { CompanyDetailsService } from 'src/service/company-details.service';

@Component({
  selector: 'app-company-update',
  templateUrl: './company-update.component.html',
  styleUrls: ['./company-update.component.css']
})
export class CompanyUpdateComponent implements OnInit {

  myForm6: FormGroup;
  companyDetails3:CompanyDetailsModel[];
  wer:any;


  constructor(private router: Router,private service:CompanyDetailsService) { }

  ngOnInit(): void {
    let qwe:string = window.localStorage.getItem('item2');
    this.wer = JSON.parse(qwe);
    {
      this.myForm6 = new FormGroup({
        ceo: new FormControl(''),
        bod: new FormControl(''),
        tover: new FormControl(''),
        desc: new FormControl(''),
        sname: new FormControl(''),
        sector: new FormControl(''),
        scode: new FormControl('')
        
      });
  }
 
  }
  
  onSubmit6(form: FormGroup){
    let companyDetails3:CompanyDetailsModel = this.wer;

    let a:string = form.value.ceo;
     let b:string = form.value.bod;
     let c:string = form.value.tover;
     let d:string = form.value.desc;
     let e:string = form.value.sname;
     let f:string = form.value.sector;
     let g:string = form.value.scode;



     if(form.value.ceo==0){a=companyDetails3.ceo;}
     if(form.value.bod==0){b=companyDetails3.board_of_directors;}
     if(form.value.tover==0){c=companyDetails3.turn_over;}
     if(form.value.desc==0){d=companyDetails3.brief_about_companies;}
     if(form.value.sname==0){e=companyDetails3.listed_in_stock_exchanges;}
     if(form.value.sector==0){f=companyDetails3.sector;}
     if(form.value.scode==0){g=companyDetails3.stock_code_in_each_stock_exchange;}


     let companyDetails4:CompanyDetailsModel = {
      company_name:companyDetails3.company_name,
      ceo:a,
      board_of_directors:b,
      turn_over:c,
      brief_about_companies:d,
      listed_in_stock_exchanges:e,
      sector:f,
      stock_code_in_each_stock_exchange:g
    }
    this.service.saveCompanyDetails(companyDetails4).subscribe(data =>{
      console.log(data.body);
   });
   window.localStorage.removeItem('item2');
   this.router.navigate(['/app-company-details']);



   
  }

}