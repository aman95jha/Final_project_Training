import { Component,OnInit } from '@angular/core';
import { UserDatabaseModel } from 'src/entity/UserDatabase';
import { UserDatabaseService } from 'src/service/user-database.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'stockProject';
}
