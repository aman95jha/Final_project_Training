import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NewUserService } from 'src/service/new-user.service';
import { CodeModel } from 'src/entity/CodeModel';
import { MailVerifyService } from 'src/service/mail-verify.service';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-mail-verify',
  templateUrl: './mail-verify.component.html',
  styleUrls: ['./mail-verify.component.css']
})
export class MailVerifyComponent implements OnInit {

  constructor(private router:Router,private service:NewUserService,private service2:MailVerifyService) { }
  myForm:FormGroup;
  code:CodeModel[];
  kuchbhi:any;

  ngOnInit(): void {
    this.service2.getCode().subscribe(data =>{
      this.code=data.body;
      console.log(data.body);
    });
    {
      this.myForm=new FormGroup({
        ncode:new FormControl('')
      });
    }

  }
  onSubmit(form:FormGroup){
    if(this.code==form.value.ncode){
      var anything = window.localStorage.getItem('item4');
      let kuchbhi = JSON.parse(anything);

      this.service.saveUserDatabase(kuchbhi).subscribe(data =>{
        console.log(data.body);
      });
      alert("email verified");
    }
    else{
      alert("wrong code entered");
    }
  }

}
