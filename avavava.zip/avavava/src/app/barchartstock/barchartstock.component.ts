import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-barchartstock',
  templateUrl: './barchartstock.component.html',
  styleUrls: ['./barchartstock.component.css']
})
export class BarchartstockComponent implements OnInit {
  public barChartOptions = {
    scaleShowVerticalsLines: false,
    responsive: true
  
  };
  public barChartLabels = ['JAN','FEB','MARCH','APRIL','MAY','JUNE','JULY'];
  
  
  public barChartType = 'bar';
  public barChartLegend = 'true';
  public barChartData = [
    {data: [1500, 2300, 4500, 5400, 1200, 1500, 4000], label: 'Series A'}
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
