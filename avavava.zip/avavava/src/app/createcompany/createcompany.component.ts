import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcompany',
  templateUrl: './createcompany.component.html',
  styleUrls: ['./createcompany.component.css']
})
export class CreatecompanyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
