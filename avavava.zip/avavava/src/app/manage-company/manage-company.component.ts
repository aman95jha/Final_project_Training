import { Component, OnInit, EventEmitter} from "@angular/core";
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { FormGroup , FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { element } from 'protractor';
import { from } from 'rxjs';
import { Action } from 'rxjs/internal/scheduler/Action';
import { format } from 'path';
@Component({
  selector: 'app-manage-company',
  templateUrl: './manage-company.component.html',
  styleUrls: ['./manage-company.component.css']
})
export class ManageCompanyComponent implements OnInit {

  userDetails:CompanyDetailsModel[];
  myForm3: FormGroup;
  company:string;
  constructor(private service:CompanyDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
 });
 

 {
   this.myForm3 = new FormGroup({
    companyname: new FormControl(''),
    ceoname: new FormControl(''),
    bod: new FormControl(''),
    turnover: new FormControl(''),
    description: new FormControl(''),
    sname: new FormControl(''),
    sector: new FormControl(''),
    scode: new FormControl(''),

   });

 }
  }
 onSubmit3(form: FormGroup){
   let CompanyDetails:CompanyDetailsModel={
    company_name : form.value.companyname,
    ceo : form.value.ceoname,
    board_of_directors : form.value.bod,
    turn_over : form.value.turn_over,
    brief_about_companies : form.value.description,
    listed_in_stock_exchanges : form.value.sname,
    sector : form.value.sector,
    stock_code_in_each_stock_exchange : form.value.scode,
   };

   this.service.saveCompanyDetails(CompanyDetails).subscribe(data =>{
     console.log(data.body);
   })
 }

 Aman(): void {
  this.service.getAllCompanyDetails().subscribe(data => {
    this.userDetails = data.body;
    console.log(data.body)
});
}

 Search(){
   if(this.company !="")
   {
      this.userDetails= this.userDetails.filter(a=>
        {return a.company_name.toLocaleLowerCase().match(this.company.toLocaleLowerCase())})
   }
   else if(this.company=="")
   {
     this.Aman();
   }


 }
  
submit2(company)
{

window.localStorage.setItem('item2',JSON.stringify(company));
this.router.navigate(['/app-company-update']);

}
 



}
