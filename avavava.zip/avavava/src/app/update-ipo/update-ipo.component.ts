import { Component, OnInit } from '@angular/core';
import { UpdateIpoModel } from 'src/entity/UpdateIpoModel';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateIpoService } from 'src/service/update-ipo.service';

@Component({
  selector: 'app-update-ipo',
  templateUrl: './update-ipo.component.html',
  styleUrls: ['./update-ipo.component.css']
})
export class UpdateIPOComponent implements OnInit {

  myForm6: FormGroup;
  ipoDetails:UpdateIpoModel[];
  wer:any;


  constructor(private router: Router,private service:UpdateIpoService) { }

  ngOnInit(): void {
    let qwe:string = window.localStorage.getItem('item3');
    this.wer = JSON.parse(qwe);
    {
      this.myForm6 = new FormGroup({
        exch: new FormControl(''),
        pps: new FormControl(''),
        tnos: new FormControl(''),
        remarks: new FormControl('')
        
      });
  }
 
  }
  
  onSubmit6(form: FormGroup){
    let ipoDetails:UpdateIpoModel = this.wer;

    let a:string = form.value.exch;
     let b:number = form.value.pps;
     let c:string = form.value.tnos;
     let d:string = form.value.remarks;



     if(form.value.exch==0){a=ipoDetails.stock_exchange;}
     if(form.value.pps==0){b=ipoDetails.price_per_share;}
     if(form.value.tnos==0){c=ipoDetails.total_number_of_shares;}
     if(form.value.remarks==0){d=ipoDetails.remarks;}
     


     let ipoDetails4:UpdateIpoModel = {
       id:ipoDetails.id,
      company_name:ipoDetails.company_name,
      stock_exchange:a,
      price_per_share:b,
      total_number_of_shares:c,
      open_date_time:ipoDetails.open_date_time,
      remarks:d
    }
    this.service.saveIpoDetails(ipoDetails4).subscribe(data =>{
      console.log(data.body);
   });
   window.localStorage.removeItem('item3');
   



   
  }

}