export interface ManageExchange{
    id : String;
	 stock_exchange :String;
	 company_name : String;
     sector : String;
}