import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CodeModel } from 'src/entity/CodeModel';
import { MailModel } from 'src/entity/MailModel';

type EntityResponseType = HttpResponse<CodeModel[]>;

@Injectable({
  providedIn: 'root'
})
export class MailVerifyService {

  constructor(private http:HttpClient) { }

  getCode():Observable<EntityResponseType>{
    return this.http.get<CodeModel[]>("http://localhost:8050/mail", {observe: 'response'});
}

saveMail(mailModel:MailModel){
   return this.http.post<MailModel>("http://localhost:8050/sendmail", mailModel, {observe: 'response'});
}

}
