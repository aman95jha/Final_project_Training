import { TestBed } from '@angular/core/testing';

import { MailVerifyService } from './mail-verify.service';

describe('MailVerifyService', () => {
  let service: MailVerifyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MailVerifyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
