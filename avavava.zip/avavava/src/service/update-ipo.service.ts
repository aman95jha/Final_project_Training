import { Injectable } from '@angular/core';
import { UpdateIpoModel } from 'src/entity/UpdateIpoModel';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

type EntityResponseType = HttpResponse<UpdateIpoModel[]>;

@Injectable({
  providedIn: 'root'
})

export class UpdateIpoService {  

  constructor(private http:HttpClient) { }

  getAllIpoDetails():Observable<EntityResponseType>{
        return this.http.get<UpdateIpoModel[]>("http://localhost:5513/students", {observe: 'response'});
  }

  saveIpoDetails(UpdateIpoModeln:UpdateIpoModel){
    return this.http.post<UpdateIpoModel>("http://localhost:5513/student", UpdateIpoModeln, {observe: 'response'});
}

}